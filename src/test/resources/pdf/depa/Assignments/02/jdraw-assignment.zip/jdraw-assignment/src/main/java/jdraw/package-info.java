/*
 * Copyright (c) 2018 Fachhochschule Nordwestschweiz (FHNW)
 * All Rights Reserved. 
 */

/**
 * Contains the main classes that start the application, trigger the
 * Spring configuration and define the GUI.
 * @author Christoph Denzler
 */
package jdraw;
